#ifndef _CFG_INFO_H_
#define _CFG_INFO_H_

#define	MAX_PROC_COUNT	100
#define CFG_PROC_SHM	0x0000001000
#define CFG_PATH		"/cfg/proc.cfg"

struct PROC_INFO{
	short	ProcNo;
	char	ProcType[32];
	char	ProcName[32];
	int 	StartUpFlag;
	int		LogFlag;
	int 	MaxRevokeCnt;
	int 	RevokeCnt;
	char	Command[256];
	char	IpAddr[16];
	int		PortNo;
	char	MessageQueueNo[20];
	char	LogFile[256];
	int		QID;
};


struct ST_INFO{
	int			ProcCount;
	struct		PROC_INFO	proc_info[MAX_PROC_COUNT]; 
};

struct  ST_INFO *ptr;

#define	PROC(i)	ptr->proc_info[i]

#define _PROC_SHM_SET_(shm_key, shm_max_size) {\
	          int uniq_key; \
	          int shm_size; \
	          int shm_id; \
	          char   *shm_addr; \
	          uniq_key = shm_key; \
	          shm_size = shm_max_size; \
	          if( 0> (shm_id= shmget(uniq_key, shm_size, IPC_CREAT | 0666) ) ) \
	              return( (char *)-1); \
	          if( (char *)NULL== (shm_addr= (char *)shmat(shm_id, 0, 0) ) ) \
	              return( (char *)-1); \
	          return( shm_addr ); \
}

#define _DECLARE_PROC_SHM(type, _func_name, shm_key, shm_max_size) \
	          type Set##_func_name() _PROC_SHM_SET_(shm_key, shm_max_size)

_DECLARE_PROC_SHM(char *, SharedMemory,           CFG_PROC_SHM,           sizeof(struct ST_INFO))

#if 0
#endif

#endif
