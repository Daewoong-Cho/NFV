//extern int proc_A0034(char *org_data);
extern _DECLARE_PROC_SHM(char *, SharedMemory,           CFG_PROC_SHM,           sizeof(struct ST_INFO))
extern _DECLARE_PROC_SHM(char *, KOSharedMemory,     KOSPI200_OPT_SHM,           sizeof(struct KOSPI200_OPT_INFO))

extern struct  ST_INFO *ptr;
extern struct  KOSPI200_OPT_INFO *koshm;
extern int	   OFFSET;
