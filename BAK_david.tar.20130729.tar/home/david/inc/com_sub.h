#define     LOG_FILE            PROC(OFFSET).LogFile

int     OFFSET = -1;

extern int     OFFSET;

